#include <iostream>
#include "board.h"
#include "piece.h"
using namespace std;

/**
 * TASK 2.1: Board copy constructor
*/
Board::Board(const Board& board) : isWhiteTurn(board.isWhiteTurn), moveMap(board.moveMap)
{
    // TODO
    for (int fileInt = 0; fileInt < 8 ; fileInt++ ){
        for (int rankInt = 0; rankInt < 8; rankInt++){
            if (board.pieces[rankInt][fileInt]) {
                pieces[rankInt][fileInt] = board.pieces[rankInt][fileInt]->clone();
            } else {
                pieces[rankInt][fileInt] = nullptr;
            }
        }
    }
    // cout << "board1" << endl;
    if (board.selectedPiece){
        //in already copied array in current object, find object in same location
        selectedPiece = piece(board.selectedPiece->getPosition());
    } else {
        selectedPiece = nullptr;
    }
    // cout << "board2" << endl;
    if (royalPieces[0]){
        //in already copied array in current object, find object in same location
        royalPieces[0] = piece(board.royalPieces[0]->getPosition());
    } else {
        royalPieces[0] = nullptr;
    }
    if (royalPieces[1]){
        //in already copied array in current object, find object in same location
        royalPieces[1] = piece(board.royalPieces[1]->getPosition());
    } else {
        royalPieces[1] = nullptr;
    }
    // cout << "board3" << endl;
}

/**
 * TASK 2.2: Board destructor
*/
Board::~Board() 
{
    // TODO
    for (int fileInt = 0; fileInt < 8 ; fileInt++ ){
        for (int rankInt = 0; rankInt < 8; rankInt++){
            delete pieces[rankInt][fileInt];
        }
    }
    // cout << "board4" << endl;
}

/**
 * TASK 5.1: Board::move(const Position&)
*/
void Board::move(const Position& destPos)
{
    // Safeguard against misusage of move()
    if (!selectedPiece) {
        cout << "ERROR: Piece not selected, cannot call move()" << endl;
        return;
    }

    // TODO
    if (piece(destPos)){
        Position pos = selectedPiece->getPosition();
        delete piece(destPos);
        piece(destPos) = selectedPiece;
        selectedPiece->setPosition(destPos);
        piece(pos) = nullptr;
        isWhiteTurn = !isWhiteTurn;
    } else {
        Position pos = selectedPiece->getPosition();
        piece(destPos) = selectedPiece;
        selectedPiece->setPosition(destPos);
        piece(pos) = nullptr;
        isWhiteTurn = !isWhiteTurn;
    }
}

/**
 * TASK 5.2: Board::getAttackingMap() const
*/
BooleanMap Board::getAttackingMap() const
{
    // TODO
    BooleanMap map;
    BooleanMap attackMap;
    for (int fileInt = 0; fileInt < 8 ; fileInt++ ){
        for (int rankInt = 0; rankInt < 8; rankInt++){
            if (piece(_FILE(fileInt), _RANK(rankInt))){
                attackMap = piece(_FILE(fileInt), _RANK(rankInt))->getMoves(*this) &= getOpponentMap(isWhiteTurn);
                map |= attackMap;
            }
        }
    }

    return map;
}

/**
 * TASK 5.3: Board::validateMoveMap()
*/
void Board::validateMoveMap()
{

    // TODO
    // cout << "validate" << endl;
    Piece* curking = royalPieces[static_cast<int>(isWhiteTurn)];
    for (int fileInt = 0; fileInt < 8 ; fileInt++ ){
        for (int rankInt = 0; rankInt < 8; rankInt++){
            Position pos = Position{_FILE(fileInt),_RANK(rankInt)};
            // Piece* curking = nullptr;
            // if (isRoyal(piece(pos))){
            //     curking = piece(pos);
            // }
            if (moveMap.cell(pos)){ //possible move location
                Board temp {*this};
                temp.move(pos);
                BooleanMap attackmap = temp.getAttackingMap();
                if (curking && attackmap.cell(curking->getPosition()) == true){
                    moveMap.cell(pos) = false;
                    cout << pos << endl;
                } 
                // else if (curking && curking->getPosition() == pos){
                //     moveMap.cell(pos) = false;
                // }


                // //if the location on this map that is the king piece is true, it isn't valid
                // cout << "gay4" << endl;
                // Piece* curKing = nullptr;
                // // cout << royalPieces[0] << royalPieces[1] << endl;
                // for (int i = 0; i < 2; ++i){
                //     if (royalPieces[i] && royalPieces[i]->getColor() == (isWhiteTurn? WHITE: BLACK)){
                //         curKing = royalPieces[i];
                //     }
                // }
                // cout << "gay5" << endl;
                // const Position kingpos = curKing->getPosition(); //seg fault here
                // cout << "gay6" << endl;
                // if (map.cell(kingpos) == true && isRoyal(this->piece(kingpos))){
                //     cout << "gay7" << endl;
                //     moveMap.cell(pos) = false;
                //     cout << "gay8" << endl;
                // }
                // // for (int fileInt = 0; fileInt < 8 ; fileInt++ ){
                // //     for (int rankInt = 0; rankInt < 8; rankInt++) {
                // //         if (map.cell(Position{_FILE(fileInt),_RANK(rankInt)}) && isRoyal(this->piece(Position{_FILE(fileInt),_RANK(rankInt)}))){
                // //             moveMap.cell(Position{_FILE(fileInt),_RANK(rankInt)}) = false;
                // //         }
                // //     }
                // // }
            }
        }
    }
    // cout << "end validate" << endl;
}

