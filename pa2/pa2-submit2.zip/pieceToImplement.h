// TASK 3: Implement the 4 Piece-derived classes here
// All classes will inherit the NamedPiece class 
// and implement the remaining pure virtual functions


// TODO 3.1: Leaper class
template <char N, int F, int R> 
class Leaper: public NamedPiece<N> {
    public:
        Leaper(Color color): NamedPiece<N>(color) {}
        // char name() const override { return N; }
        virtual Piece* clone() const override {
            return new Leaper<N,F,R>(*this);
        }
        virtual BooleanMap getMoves(const Board &board) const override {
            Position curr = this->getPosition();
            Vector vec {F,R};
            if (this->isWhite()){
                if (board.piece(vec + curr) == nullptr){
                    //if nullptr, no piece, so valid move
                    BooleanMap map {};
                    map.cell(vec + curr) = true;
                    // std::cout << "gay1" << std::endl;
                    return map;
                }
                else if (board.piece(vec + curr)->getColor() == BLACK){
                    BooleanMap map {};
                    map.cell(vec + curr) = true;
                    return map;
                } else {
                    BooleanMap map {};
                    return map;
                }
            } 
            else {
                if (board.piece(vec * -1 + curr) == nullptr){
                    //if nullptr, no piece, so valid move
                    BooleanMap map {};
                    map.cell(vec * -1 + curr) = true;
                    return map;
                }
                if (board.piece(vec * -1 + curr)->getColor() == WHITE){
                    BooleanMap map {};
                    map.cell(vec * -1 + curr) = true;
                    return map;
                } else {
                    BooleanMap map {};
                    return map;
                }
            }
        }
        
};


// TODO 3.2: Rider class
template <char N, int F, int R, int RANGE> 
class Rider: public NamedPiece<N> {
    public:
        Rider(Color color): NamedPiece<N>(color) {}
        // char name() const override { return N; }
        virtual BooleanMap getMoves(const Board &board) const override {
            // Vector move_dir{F,R};
            Position pos = this->getPosition();
            BooleanMap map;
            Vector vec; // Define the variable 'vec' outside the conditional statement
            if (Piece::isWhite()) {
                vec = Vector{F, R};  // If 'isWhite()' is true, assign {F, R} to 'vec'
            } else {
                vec = Vector{-F, -R};  // If 'isWhite()' is false, assign {-F, -R} to 'vec'
            }
            for (int i = 1; i < RANGE + 1; ++i){
                if (!board.piece(vec * i + pos)){
                    //if piece that position is nullptr
                    map.cell(vec * i + pos) = true;
                } else if (board.piece(vec * i + pos)->isOpponent(*board.piece(pos))) {
                    // Piece::isOpponent(*board.piece(pos))
                    //we know not nullptr, so now must check if not same color as current piece
                    // check same color
                    //implies take the piece
                    map.cell(vec * i + pos) = true;
                    return map;

                } else {
                    //piece exists but same color
                    return map;
                }
            }
            return map;
        }
        Piece* clone() const override {
            return new Rider(*this);
        }

};

//TASK 3.3
template <char N, typename P1, typename P2> 
class Compound: public NamedPiece<N> {
    public:
        Compound(Color color): NamedPiece<N>(color) {}
        // char name() const override { return N; }
        virtual BooleanMap getMoves(const Board &board) const override {
            P1 p1temp {this->getColor()};
            P2 p2temp {this->getColor()};
            Piece* piece1ptr = p1temp.clone();
            Piece* piece2ptr = p2temp.clone();
            Position curr = this->getPosition();

            const Board temp1 = board.getTempBoard(piece1ptr,curr);
            const Board temp2 = board.getTempBoard(piece2ptr,curr);

            const Piece* temppiece1 = temp1.piece(curr);
            const Piece* temppiece2 = temp2.piece(curr);
            BooleanMap tempboard1 = temppiece1->getMoves(temp1);
            BooleanMap tempboard2 = temppiece2->getMoves(temp2);
            // delete piece1ptr; delete piece2ptr;

            return tempboard1 |= tempboard2;
        }
        Piece* clone() const override {
            return new Compound<N,P1,P2>(*this);
        }
};


// TODO 3.4: Divergent class
template <char N, typename M, typename C> 
class Divergent: public NamedPiece<N> {
    public:
        Divergent(Color color): NamedPiece<N>(color) {}
        // char name() const override { return N; }
        virtual BooleanMap getMoves(const Board &board) const override{
            C ctemp {this->getColor()};
            M mtemp {this->getColor()};
            Piece* capPiece = ctemp.clone();
            Piece* movePiece = mtemp.clone();
            Position curr = Piece::getPosition();

            const Board temp1 = board.getTempBoard(capPiece, curr);
            const Board temp2 = board.getTempBoard(movePiece, curr);

            const Piece* temppiece1 = temp1.piece(curr);
            const Piece* temppiece2 = temp2.piece(curr);
            BooleanMap tempboard1 = temppiece1->getMoves(temp1);
            BooleanMap tempboard2 = temppiece2->getMoves(temp2);
            
            BooleanMap oppMap = board.getOpponentMap(this->isWhite());
            BooleanMap capMoves = tempboard1 &= oppMap;
            BooleanMap moveMoves = tempboard2 &= ~oppMap;
            
            // delete capPiece; delete movePiece;
            return moveMoves |= capMoves;
        }
        Piece* clone()const override{
            return new Divergent<N,M,C>(*this);
        }
};